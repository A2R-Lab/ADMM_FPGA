#ifndef ADMM_H
#define ADMM_H

#include "data_types.h"
#include "data.h"

void forward_substitution(
    const fp_t b[N_VAR],
    bool use_traj_q,
    int traj_idx,
    fp_t x[N_VAR]
);

void backward_substitution(
    const fp_t b[N_VAR],
    fp_t x[N_VAR]
);

void AT_mul(
    const fp_t x[N_CONSTR],
    fp_t ATx[N_VAR]
);

void ADMM_iteration(
    fp_t x[N_VAR],
    fp_t b[N_VAR],
    fp_t y[N_CONSTR],
    fp_t current_state[12],
    bool use_traj_q,
    int traj_idx,
    fp_t dynamic_min,
    fp_t dynamic_max,
    const fp_t q_vec[N_VAR] = nullptr,
    bool use_q_vec = false
);

void ADMM_solver(
    ap_uint<418> current_in_bits,
    ap_uint<128> &command_out_bits
);

void ADMM_benchmark_solve(
    const fp_t current_state[12],
    const fp_t q_vec[N_VAR],
    fp_t dynamic_min,
    fp_t dynamic_max,
    fp_t out_x[N_VAR]
);

fp_t admm_test_rho_mul(fp_t v);
fp_t admm_test_rho_div(fp_t v);
int admm_test_fp_width();
int admm_test_acc_width();

#endif // ADMM_H
